#include <at89x52.h>
#include <stdio.h>
#include <intrins.h>

#define PAINELLED P2
#define LED_COIN P2_0		//LED de informativo se colocaram coin
#define LED_CAFE P2_1	//LED de informativo se selecionaram cafe
#define LED_CHA P2_3  //LED de informativo se selecionaram cha

const ON = 1;
const OFF = 0;
delay_s(int segundos); 
 /* Essa interrup��o serve para indicar se foi colocado dinheiro na maquina 
			e tambem serve para selecionar a opcao cafe caso o dinheiro seja 
			colocado antes
 */
void interrupcao1 () interrupt 0{
		if(LED_COIN == ON){ //testa se ja foi introduzido dinheiro na maquina
			LED_CAFE = ON;  // selecionou cafe
			delay_s(4);			// acender o led por um tempo para informar a selecao
		

			PAINELLED = OFF; // ENCERROU E VOLTA PARA O ESTADO INICIAL
		}
		else{
			LED_COIN = ON; // o dinheiro foi colocado
			
		}
}

void interrupcao2 () interrupt 1{
		if(LED_COIN == ON){ // testa se ja foi introduzido dinheiro na maquina
				LED_CHA = ON;  	// selecionou cha
				delay_s(4);			// acender o led por um tempo para informar a selecao
				
				PAINELLED = OFF; // ENCERROU E VOLTA PARA O ESTADO INICIAL
		}
}

delay_s(int segundos)
{
   int i;
   for(i=0 ; i < segundos ;i++)
	{
		_nop_();
	}
}

void main(){
	EA = 1;
	EX0 = 1;
	EX1 = 1;
	
	PAINELLED = OFF;	
	
	while(1){
		
	}

}
